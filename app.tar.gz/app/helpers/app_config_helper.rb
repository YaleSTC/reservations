module AppConfigHelper
end
