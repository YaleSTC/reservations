module BlackOutsHelper
end
