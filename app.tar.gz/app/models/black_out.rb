class BlackOut < ActiveRecord::Base

  belongs_to :equipment_model
  attr_accessible :start_date, :end_date, :notice, :equipment_model_id, :black_out_type, :created_by
 
  def date_is_blacked_out(date)
    if BlackOut.where(:equipment_model_id => 0).where(:start_date => date)
       return true
    elsif BlackOut.where(:equipment_model_id => 0).where(:end_date => date)
      return true
    end
    return false
  end

end


#   errorString
#   if (Start Date is blackout or notice)
#     add to errorString
#   if (End Date is blackout or notice)
#     add to errorString
#   return errorString
#
#
#
#
