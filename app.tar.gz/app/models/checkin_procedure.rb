class CheckinProcedure < ActiveRecord::Base
  belongs_to :equipment_model
end
