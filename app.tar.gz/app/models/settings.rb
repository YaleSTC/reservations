class Settings < RailsSettings::Settings
  
end